package project;

public class dot {

	public static void main(String[] args) {
		 
	    
	    {
	        int password=1000;
	        if(password==1000)
	            {
	             System.out.println("accepted");
	             System.out.println("welcome user");
	            } 
	        else
	        {
	            System.out.println("sorry not accepted");
	        }
	 
	    }
	 

	}

}
