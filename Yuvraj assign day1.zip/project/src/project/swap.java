package project;

public class swap {

	public static void main(String[] args) {
int a=10,b=20,temp;
System.out.println("before swap");
System.out.println("a="+a);
System.out.println("b="+b);

temp=a;
a=b;
b=temp;

System.out.println("after swap");
System.out.println("a="+a);
System.out.println("b="+b);

}
}