package project;

public class evenodd {

	public static void main(String[] args) 
	{int no=90;
	if(no%2==0)
	{
		System.out.println("no is even");
		
	}
	else
	{System.out.println("no is odd");
	}

}
}